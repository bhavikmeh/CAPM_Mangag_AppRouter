sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("cust.inc.customers.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);